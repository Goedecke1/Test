var APP_DATA = {
  "scenes": [
    {
      "id": "0-bathroom",
      "name": "Bathroom",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1630,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -2.126900832577025,
          "pitch": 0.2860315051380873,
          "rotation": 0,
          "target": "1-inside-shower"
        },
        {
          "yaw": -0.718384152093325,
          "pitch": 0.5161000363014825,
          "rotation": 5.497787143782138,
          "target": "2-countertop"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.250727873832707,
          "pitch": -0.1603538553904844,
          "title": "Wall Sconce&nbsp;",
          "text": "Beautiful chrome sconce with LED lightiung"
        },
        {
          "yaw": -0.47270840079316834,
          "pitch": 0.9660333757663562,
          "title": "Extra Deep Vanity",
          "text": "Extra storage underneath and on the countertop."
        },
        {
          "yaw": 1.4678154184857028,
          "pitch": 0.6975370007106445,
          "title": "Full Feature Flusher :)",
          "text": "Text"
        },
        {
          "yaw": -1.7765593616759503,
          "pitch": 1.124763759315977,
          "title": "Some Such Tile",
          "text": "The Bestest&nbsp;"
        }
      ]
    },
    {
      "id": "1-inside-shower",
      "name": "Inside Shower",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1630,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.7926970040319041,
          "pitch": 0.10667110097731225,
          "rotation": 0,
          "target": "0-bathroom"
        },
        {
          "yaw": -1.3200807848093437,
          "pitch": 0.21085899849536638,
          "rotation": 0,
          "target": "2-countertop"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 0.09674911586207813,
          "pitch": 0.09511253197278968,
          "title": "Recess Niche&nbsp;",
          "text": "Convenient and attractive soap and shampoo. Notice how the granite pattern contiues from one shelf to the next."
        },
        {
          "yaw": 0.11341096233375225,
          "pitch": -1.0563532729500764,
          "title": "Rainfall Shower Head",
          "text": "Text"
        },
        {
          "yaw": 0.5629353474938998,
          "pitch": -0.8433883934303434,
          "title": "Hand Held Sprayer",
          "text": "Text"
        },
        {
          "yaw": -3.079913601719298,
          "pitch": 1.0578596540693752,
          "title": "Heated Shower Bench",
          "text": "Luxurious comfort!"
        }
      ]
    },
    {
      "id": "2-countertop",
      "name": "Countertop",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 1630,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": -0.6160374404641349,
          "pitch": 0.00908643402162923,
          "rotation": 0,
          "target": "1-inside-shower"
        },
        {
          "yaw": -1.4509438022142902,
          "pitch": -0.029370956180834185,
          "rotation": 0,
          "target": "0-bathroom"
        }
      ],
      "infoHotspots": [
        {
          "yaw": 1.945353547245385,
          "pitch": -0.07528146530012236,
          "title": "Electric controls",
          "text": "Maximize control with a timed fan and dimmable lights."
        },
        {
          "yaw": 0.15526928169364496,
          "pitch": -0.2301315068658134,
          "title": "Hunter Douglas Shade",
          "text": "Privacy and thermal performance with Hunter Douglas Quality and warranty.<div><br></div>"
        },
        {
          "yaw": -0.6437930738813797,
          "pitch": -1.0053612194567911,
          "title": "Quiet Ceiling Fan",
          "text": "Removing stale, damp air keeps a bathroom from molding."
        },
        {
          "yaw": 2.418769692672041,
          "pitch": 0.13206047812792043,
          "title": "Beautiful Granite",
          "text": "Text"
        }
      ]
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
